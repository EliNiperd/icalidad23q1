"use strict";
exports.id = 435;
exports.ids = [435];
exports.modules = {

/***/ 435:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EA": () => (/* binding */ typeParameter),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "l6": () => (/* binding */ usegetPool)
/* harmony export */ });
/* unused harmony exports closePools, connectDB */
/* harmony import */ var mssql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9424);
/* harmony import */ var mssql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mssql__WEBPACK_IMPORTED_MODULE_0__);

/*global Map*/ const pools = new Map();
const dbSettings = {
    user: "sa",
    password: "iCalidad2012",
    database: "iCalidadCCMSLP22",
    server: "CABLESAPPSLPPRD",
    port: +"1433",
    pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000
    },
    options: {
        encrypt: true,
        trustServerCertificate: true
    }
};
const usegetPool = async (name)=>{
    //console.log(process.env.NEXT_PUBLIC_DB_USER)
    //console.log(dbSettings);
    if (!pools.has(name)) {
        if (!dbSettings) {
            throw new Error("Pool does not exists");
        }
        const pool = new (mssql__WEBPACK_IMPORTED_MODULE_0___default().ConnectionPool)(dbSettings);
        const close = pool.close.bind(pool);
        pool.close = (...args)=>{
            pools.delete(name);
            return close(...args);
        };
        pools.set(name, pool.connect());
    }
    return pools.get(name);
};
/*global Promise*/ const closePools = async ()=>Promise.all(Array.from(pools.values()).map((connect)=>{
        return connect.then((pool)=>pool.close());
    }));
const connectDB = async ()=>{
    try {
        const pool = await msql.connect(dbSettings);
        //pool().connected()
        return pool;
    } catch (error) {
        console.log(error);
    }
};
const typeParameter = async ()=>{
    const types = (mssql__WEBPACK_IMPORTED_MODULE_0___default().TYPES);
    return types;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (usegetPool); //import sql from 'mssql'
 /*
const dbSettings = {
    user: process.env.NEXT_PUBLIC_DB_USER,
    password: process.env.NEXT_PUBLIC_DB_PASS,
    database: process.env.NEXT_PUBLIC_DB_NAME,
    server: process.env.NEXT_PUBLIC_DB_HOST,
    port: 1433,
    pool: {
      max: 10,
      min: 0,
      idleTimeoutMillis: 30000
    },
    options: {
      encrypt: true, // for azure
      trustServerCertificate: true // change to true for local dev / self-signed certs
    }
  }
*/  //const Context = React.creacteContext({})
 /*
export function PoolContextProvider({ children}){
  
}*/  /*
   export default async function getPool() {

        //try {
            const pool = await sql.connect(dbSettings);
            return pool;
            //const result = await pool.request().query('select * from gen_templeado');
            //console.log(result);
            ///return poolSQL
            // make sure that any items are correctly URL encoded in the connection string where id = ${value}
           //await sql.connect('Server=localhost,1433;Database=iCalidadLamesa;User Id=sa;Password=Niperd2012;Encrypt=true')
            //const result = await sql.query('select * from Gen_TEmpleado ')
            //console.dir(result)
        //} catch (err) {
        //    console.log(err)
            // ... error checks
        //}
    }*/  //getConnection();


/***/ })

};
;