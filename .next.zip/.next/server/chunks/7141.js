"use strict";
exports.id = 7141;
exports.ids = [7141];
exports.modules = {

/***/ 7141:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuToggle": () => (/* binding */ MenuToggle),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const Path = (props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.path, {
        fill: "transparent",
        strokeWidth: "2",
        stroke: "hsl(0, 0%, 18%)",
        strokeLinecap: "round",
        ...props
    });
const MenuToggle = ({ toggle  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            onClick: toggle,
            className: "cursor-pointer absolute top-3 left-5 w-11 h-11 rounded-full bg-[#DEF0FA] border-[#30A9ED] shadow-md shadow-slate-500",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                width: "44",
                height: "44",
                viewBox: "0 0 44 44",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Path, {
                        variants: {
                            closed: {
                                d: "M 13 16 L 30 16"
                            },
                            open: {
                                d: "M 13 16 L 30 30"
                            }
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Path, {
                        d: "M 13 23 L 30 23",
                        variants: {
                            closed: {
                                opacity: 1
                            },
                            open: {
                                opacity: 0
                            }
                        },
                        transition: {
                            duration: 0.1
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Path, {
                        variants: {
                            closed: {
                                d: "M 13 30 L 30 30"
                            },
                            open: {
                                d: "M 13 30 L 30 16"
                            }
                        }
                    })
                ]
            })
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenuToggle); /*
 <motion.div className="absolute top-3 left-5 w-auto h-auto p-2 items-start rounded-md bg-[#DEF0FA] border-[#30A9ED] shadow-md shadow-slate-500"
      animate={{
        x: "500px",
      }}

      transition={{
        type:"delay",
        duration: 2,
      }}
    >
      <h1 className="text-3xl bg-[#30A9ED] my-4 mr-4 p-2 rounded-md text-white ">Invitado Especial:</h1>
    </motion.div>
<button onclick={toggle} className='cursor-pointer absolute top-4 left-4 w-11 h-11 rounded-full bg-red-700' >
<svg width="23" height="23" viewBox="0 0 23 23" >
    <Path variants={{
        closed: { d: "M 2 2.5 L 20 2.5" },
        open: { d: "M 3 16.5 L 17 2.5" }
    }}
    />
    <Path d="M 2 9.423 L 20 9.423"
        variants={{ 
            closed: { opacity: 1 },
            open: { opacity: 0 }
        }}
        transition={{ duration: 0.1 }} 
    />
</svg>
</button>   
<svg viewBox="0 0 60 60">
    <circle cx="30" cy="30" r="20" />
      <Path d="m14,28 h32 " stroke='#ffffff' strokeWidth='.02em' strokeLinecap="round" fill="transparent"   />
      <Path d="m14,30 h32 " stroke='#ffffff' strokeWidth='.02em' strokeLinecap="round" fill="transparent"   />
      <Path d="m14,32 h32 " stroke='#ffffff' strokeWidth='.02em' strokeLinecap="round" fill="transparent"   />
    </svg>

*/ 

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;