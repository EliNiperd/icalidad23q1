"use strict";
exports.id = 2773;
exports.ids = [2773];
exports.modules = {

/***/ 2773:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ DashBoard_Avatar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/photo-Avatar1.jpg
/* harmony default export */ const photo_Avatar1 = ({"src":"/_next/static/media/photo-Avatar1.342cfb53.jpg","height":844,"width":844,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAP/xAAdEAACAgIDAQAAAAAAAAAAAAABAgARAwUSFTHB/8QAFQEBAQAAAAAAAAAAAAAAAAAAAwX/xAAYEQEAAwEAAAAAAAAAAAAAAAABAAIRIf/aAAwDAQACEQMRAD8AkNnoW32XJ2eFiVVVYk0DVcQfK+xESsWxeQdUn//Z","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./pages/DashBoard/Avatar.jsx



const Avatar = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "avatar online relative",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-12 rounded-full ring ring-primary ring-offset-base-100 ring-offset-1",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: photo_Avatar1,
                    alt: "Avatar",
                    className: "rounded-full",
                    layout: "fill"
                })
            })
        })
    });
};
/* harmony default export */ const DashBoard_Avatar = (Avatar);


/***/ })

};
;