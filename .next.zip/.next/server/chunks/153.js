"use strict";
exports.id = 153;
exports.ids = [153];
exports.modules = {

/***/ 153:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _SideNavBar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7903);
/* harmony import */ var _Avatar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2773);
/* harmony import */ var _NavBar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(156);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_NavBar__WEBPACK_IMPORTED_MODULE_5__]);
_NavBar__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



//import Image from "next/image";
//import menuIcon_01 from "./public/menuIcon_01.svg";



//import Search from "./Search";
//import { IoMenuSharp } from "react-icons/io5";
const HomeDashBoard = ({ children  })=>{
    //console.log(session);
    const { 0: isMenuOpen , 1: setIsMenuOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: activeMenuId , 1: setActiveMenuId  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const { 0: contador , 1: setContador  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
    const toggleMenu = ()=>{
        setIsMenuOpen(!isMenuOpen);
        setContador(contador + 1);
    };
    const closeMenu = ()=>{
        setIsMenuOpen(false);
        setActiveMenuId(null);
    };
    const handleMenuItemClick = (menuId)=>{
        //closeMenu();
        setActiveMenuId(menuId);
    };
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_1__.useSession)();
    //const [isOpen, toggleOpen] = useCycle(false, true);
    //const containerRef = useRef(null);
    //  const { height } = useWindowSize();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col h-screen ",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
                className: " text-neutral-900 bg-neutral flex justify-between items-center shadow-lg rounded-br rounded-bl p-3",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-row",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: " basis-1/4 text-3xl hover:cursor-pointer peer",
                                onClick: toggleMenu,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                    className: "hover:scale-125",
                                    width: "24",
                                    height: "24",
                                    viewBox: "0 0 24 24",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M4 5L24 5",
                                            stroke: "#141B34",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M4 12L24 12",
                                            stroke: "#141B34",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M4 19L24 19",
                                            stroke: "#141B34",
                                            strokeWidth: "2",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "ml-4 text-lg font-bold basis-1/4",
                                children: "iCalidad"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-max ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavBar__WEBPACK_IMPORTED_MODULE_5__["default"], {
                            conta: contador
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Avatar__WEBPACK_IMPORTED_MODULE_4__["default"], {
                        IdUser: session?.user?.id
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-1 ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `fixed top-0 left-0 w-56 h-full bg-white shadow-md z-10 overflow-y-auto 
        transition-all duration-500 transform ${isMenuOpen ? "" : "-translate-x-full"}`,
                        children: isMenuOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SideNavBar__WEBPACK_IMPORTED_MODULE_3__["default"], {
                            onMenuItemClick: handleMenuItemClick,
                            activeMenuId: activeMenuId,
                            onCloseMenu: closeMenu,
                            IdUser: session?.user?.id,
                            isMenuOpen: isMenuOpen
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 ml-6 p-4 ",
                        onClick: closeMenu,
                        children: children
                    })
                ]
            })
        ]
    });
};
/*
// Hook
function useWindowSize() {
    // Initialize state with undefined width/height so server and client renders match
    // Learn more here: https://joshwcomeau.com/react/the-perils-of-rehydration/
    //const dimensions = useRef({ width: 0, height: 0 });
    const [windowSize, setWindowSize] = useState({
      width: undefined,
      height: undefined,    
    });
    useEffect(() => {
      // Handler to call on window resize
      function handleResize() {
        // Set window width/height to state
        setWindowSize({
          width: window.innerWidth,
          height: window.innerHeight,
        });
      }
      // Add event listener
      window.addEventListener("resize", handleResize);
      // Call handler right away so state gets updated with initial window size
      handleResize();
      // Remove event listener on cleanup
      return () => window.removeEventListener("resize", handleResize);
    }, []); // Empty array ensures that effect is only run on mount
    return windowSize;
  }
*/ async function getServerSideProps({ req  }) {
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_1__.getSession)({
        req
    });
    //console.log('session', session);
    if (!session) {
        return {
            redirect: {
                destination: "/",
                permanent: false
            }
        };
    }
    return {
        props: {
            session
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeDashBoard);
/*
import { useCycle } from "framer-motion";



const sidebar = {
  open: (height = 1000 ) => ({
    gridColumn: "3",
    clipPath: `circle(${height * 2 + 200}px at 48px 48px)`,
    transition: {
      type: "spring",
      stiffness: 20,
      restDelta: 2,
    },
  }),
  closed: {
    clipPath: "circle(30px at 44px 44px)",
    gridColumn: "1",
    transition: {
      delay: 0.5,
      type: "spring",
      stiffness: 400,
      damping: 40,
    },
  },
};

*/ //  {/** 2. Header */}
//  <div id='nav-bar-header' className="flex row-star-1 col-start-2 col-span-12 w-full justify-between self-end  text-black outline-1 outline-double outline-fuchsia-700">
//  {/** 2.1 Logo y Side Bar */}
//  <div className=" h-full bg-yellow-400 text-black  outline-1 outline-double outline-yellow-700">
//      <h1 className="text-lx4 ">Logo y Side Bar</h1>
//  </div>
//  {/** 2.2 Search and NavBar */}
//  <div className="flex flex-row justify-between  p-2 gap-4  w-2/4 h-full self-end text-black  outline-1 outline-double outline-blue-700">
//      <NavBar />
//      <Search />
//  </div>
//  {/** 2.3 Avatar   bg-green-400 text-white  */}
//  <div className=" w-24 h-full pr-3  outline-1 outline-double outline-green-50-700">
//      <Avatar />
//  </div>
// </div>
{}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;