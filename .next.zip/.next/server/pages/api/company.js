"use strict";
(() => {
var exports = {};
exports.id = 9265;
exports.ids = [9265];
exports.modules = {

/***/ 9424:
/***/ ((module) => {

module.exports = require("mssql");

/***/ }),

/***/ 4746:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var lib_database_connection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(435);

async function handler(req, res) {
    try {
        const request = req;
        const pool = await (0,lib_database_connection__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP)();
        const result = await pool.request().query("select TOP 1 * from Gen_TConfiguracionEMpresa");
        console.log(result.recordset, request);
        return res.status(200).json(result.recordset);
    } catch (err) {
        return res.status(500).json({
            error: "failed to load data"
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [435], () => (__webpack_exec__(4746)));
module.exports = __webpack_exports__;

})();