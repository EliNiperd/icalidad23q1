"use strict";
(() => {
var exports = {};
exports.id = 498;
exports.ids = [498];
exports.modules = {

/***/ 8450:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ fetchData)
/* harmony export */ });
const getSuspender = (promise)=>{
    let status = "pending";
    let response;
    const suspender = promise.then((res)=>{
        status = "success";
        response = res;
    }, (err)=>{
        status = "error";
        response = err;
    });
    const read = ()=>{
        switch(status){
            case "pending":
                throw suspender;
            case "error":
                throw response;
            default:
                return response;
        }
    };
    return {
        read
    };
};
function fetchData(url) {
    const promise = fetch(url).then((response)=>response.json()).then((json)=>json);
    return getSuspender(promise);
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8450));
module.exports = __webpack_exports__;

})();