"use strict";
(() => {
var exports = {};
exports.id = 2882;
exports.ids = [2882];
exports.modules = {

/***/ 5088:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handlerUserAction)
/* harmony export */ });
function handlerUserAction(req, res) {
    switch(req.method){
        case "GET":
            res.status(200).json({
                message: "Success in GET request"
            });
            break;
        case "POST":
            res.status(200).json({
                message: "Success in POST request"
            });
            break;
        default:
            res.status(405).json({
                message: `El método HTTP ${req.method} no está disponible para este objeto`
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5088));
module.exports = __webpack_exports__;

})();