"use strict";
(() => {
var exports = {};
exports.id = 5886;
exports.ids = [5886];
exports.modules = {

/***/ 9424:
/***/ ((module) => {

module.exports = require("mssql");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9911:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getPool": () => (/* binding */ getPool)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mssql__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9424);
/* harmony import */ var mssql__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mssql__WEBPACK_IMPORTED_MODULE_1__);


const user = {
    userName: "erodriguez",
    password: "xyz123",
    fullName: "El\xed Rodr\xedguez S",
    avatarUser: "ok"
};
const dbSettings = {
    user: "sa",
    password: "iCalidad2012",
    database: "iCalidadCCMSLP22",
    server: "CABLESAPPSLPPRD",
    port: "1433",
    pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000
    },
    options: {
        encrypt: true,
        trustServerCertificate: true // change to true for local dev / self-signed certs
    }
};
const getPool = async ()=>{
    try {
        const poolSQL = await mssql__WEBPACK_IMPORTED_MODULE_1___default().connect(dbSettings);
        //return poolSQL
        // make sure that any items are correctly URL encoded in the connection string where id = ${value}
        //await sql.connect('Server=localhost,1433;Database=iCalidadLamesa;User Id=sa;Password=Niperd2012;Encrypt=true')
        const result = await poolSQL.request().query("select * from Gen_TEmpleado ");
        return result.json();
    //console.dir(result)
    } catch (err) {
        console.log(err);
    // ... error checks
    }
};
const UserContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createContext({
    user: user
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserContext);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9911));
module.exports = __webpack_exports__;

})();