"use strict";
(() => {
var exports = {};
exports.id = 108;
exports.ids = [108];
exports.modules = {

/***/ 9424:
/***/ ((module) => {

module.exports = require("mssql");

/***/ }),

/***/ 3831:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var mssql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9424);
/* harmony import */ var mssql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mssql__WEBPACK_IMPORTED_MODULE_0__);
//import getPool from "../../database/connection"

const dbSettings = {
    user: "sa",
    password: "iCalidad2012",
    database: "iCalidadCCMSLP22",
    server: "CABLESAPPSLPPRD",
    port: "1433",
    pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000
    },
    options: {
        encrypt: true,
        trustServerCertificate: true // change to true for local dev / self-signed certs
    }
};
async function handler(req, res) {
    try {
        const poolSQL = await mssql__WEBPACK_IMPORTED_MODULE_0___default().connect(dbSettings);
        const result = await poolSQL.request().query("select * from Gen_TEmpleado ");
        res.status(200).json({
            result
        });
    //console.dir(result)
    } catch (err) {
        res.status(500).json({
            error: "failed to load data"
        });
    }
    res.json();
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3831));
module.exports = __webpack_exports__;

})();