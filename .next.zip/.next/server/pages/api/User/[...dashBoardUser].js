"use strict";
(() => {
var exports = {};
exports.id = 5394;
exports.ids = [5394];
exports.modules = {

/***/ 9424:
/***/ ((module) => {

module.exports = require("mssql");

/***/ }),

/***/ 8721:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handlerUserAction)
/* harmony export */ });
/* harmony import */ var lib_database_connection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(435);

async function handlerUserAction(req, res) {
    //console.log("req", req.method);
    const requestOptions = {
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(req.body)
    };
    switch(req.method){
        case "GET":
            try {
                const { dashBoardUser  } = req.query;
                const typeParam = await (0,lib_database_connection__WEBPACK_IMPORTED_MODULE_0__/* .typeParameter */ .EA)();
                const pool = await (0,lib_database_connection__WEBPACK_IMPORTED_MODULE_0__/* .usegetPool */ .l6)("Default");
                const request = await pool.request();
                //console.log('dashBoardUser', dashBoardUser);
                await request.input("p_IdEmpleado", typeParam.Int, dashBoardUser[1]);
                await request.input("p_Version", typeParam.Int, dashBoardUser[2]);
                await request.input("p_IdMenuFather", typeParam.Int, dashBoardUser[3]);
                const result = await request.execute("PF_Gen_TMenu");
                const { rowsAffected , recordsets  } = result;
                //console.log(JSON.stringify(recordsets));
                //const recordset = result.recordset;
                res.status(200).json({
                    recordsets,
                    rowsAffected
                });
            } catch (error) {
                console.log("mensaje de error: ", error);
                res.status(500).json({
                    error: error.message
                });
            }
            break;
        case "POST":
            res.status(200).json({
                message: "Success in POST request",
                requestOptions
            });
            break;
        default:
            res.status(405).json({
                message: `El método HTTP ${req.method} no está disponible para este objeto`
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [435], () => (__webpack_exec__(8721)));
module.exports = __webpack_exports__;

})();